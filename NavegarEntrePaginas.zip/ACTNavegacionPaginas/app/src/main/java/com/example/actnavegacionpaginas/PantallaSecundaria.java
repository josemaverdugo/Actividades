package com.example.actnavegacionpaginas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class PantallaSecundaria extends AppCompatActivity {

    private Spinner spinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_secundaria);


        spinner=findViewById(R.id.spinner1);

        ArrayList<String> elementos=new ArrayList<>();
        elementos.add("Hola");
        elementos.add("Buenas");
        elementos.add("Noches");


        ArrayAdapter<String> adapter=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, elementos);

        spinner.setAdapter(adapter);


    }
        public void paginaWeb (View view){

        String url="https://docs.oracle.com/javase/8/docs/api/";
            Intent i1=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(i1);

}

}